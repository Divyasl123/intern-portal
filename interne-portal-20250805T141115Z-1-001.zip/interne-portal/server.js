const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

// Home redirect to login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Serve login page
app.get('/login', (req, res) => {
  res.render('login');
});

// Serve signup page
app.get('/signup', (req, res) => {
  res.render('signup');
});

// Serve forgot password page
app.get('/forgot-password', (req, res) => {
  res.render('forgot');
});

// Handle login form
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = JSON.parse(fs.readFileSync('users.json', 'utf-8'));

  const user = users.find(
    u => (u.email === email || u.phone === email) && u.password === password
  );

  if (user) {
    res.render('dashboard', { user });
  } else {
    res.send('Invalid credentials. <a href="/login">Try again</a>');
  }
});

// Handle signup form
app.post('/signup', (req, res) => {
  const { name, email, phone, password } = req.body;
  let users = [];

  if (fs.existsSync('users.json')) {
    users = JSON.parse(fs.readFileSync('users.json', 'utf-8'));
  }

  const alreadyExists = users.some(u => u.email === email || u.phone === phone);

  if (alreadyExists) {
    res.send('User already exists. <a href="/login">Login here</a>');
  } else {
    users.push({ name, email, phone, password });
    fs.writeFileSync('users.json', JSON.stringify(users, null, 2));
    res.send('Signup successful! <a href="/login">Login now</a>');
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
