// Wait until DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  const signupForm = document.getElementById("signupForm");
  const loginForm = document.getElementById("loginForm");

  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();

      if (!name || !email || !password) {
        alert("Please fill all fields");
        return;
      }

      // You can send data to backend using fetch() if server is connected
      alert("Signup successful!");
      window.location.href = "/login";
    });
  }

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();

      if (!email || !password) {
        alert("Please enter email and password");
        return;
      }

      // Dummy check – later replace with real fetch to server
      alert("Login successful!");
      window.location.href = "/dashboard";
    });
  }
});
